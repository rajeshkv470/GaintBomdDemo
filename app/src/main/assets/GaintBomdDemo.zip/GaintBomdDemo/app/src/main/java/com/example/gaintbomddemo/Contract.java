package com.example.gaintbomddemo;

public interface Contract {
    interface View<T extends Presenter> {
        void setData(Object data);

        void setPresenter(T presenter);

        void showProgress();

        void hideProgress();
    }

    interface Presenter {
        void logoutClick();

        void start();
    }
}
