package com.example.gaintbomddemo.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GaintBombResponse {

    @SerializedName("status_code")
    public int statusCode;

    @SerializedName("results")
    public List<Result> results;

    public class Result {

        @SerializedName("id")
        public int id;

        @SerializedName("name")
        public String name;

        @SerializedName("deck")
        public String deck;

        @SerializedName("date_last_updated")
        public String dateLastUpdated;

        @SerializedName("image")
        public Image image;
    }

    public class Image {
        @SerializedName("icon_url")
        public String iconUrl;
    }

}
