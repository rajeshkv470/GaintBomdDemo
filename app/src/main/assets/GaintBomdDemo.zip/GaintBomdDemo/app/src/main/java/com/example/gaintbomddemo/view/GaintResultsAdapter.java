package com.example.gaintbomddemo.view;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.gaintbomddemo.R;
import com.example.gaintbomddemo.model.GaintBombResponse;

import java.util.ArrayList;
import java.util.List;


public class GaintResultsAdapter extends RecyclerView.Adapter<GaintResultsAdapter.ViewHolder> {
    List<GaintBombResponse.Result> mResults;
    private final LayoutInflater inflater;

    public GaintResultsAdapter(Context context) {
        inflater = LayoutInflater.from(context);
        mResults = new ArrayList<>();
    }

    public void setList(List<GaintBombResponse.Result> results) {
        if (results == null) {
            return;
        }
        mResults.addAll(results);
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_results_adapter, null, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.textViewName.setText(mResults.get(position).name);
    }

    @Override
    public int getItemCount() {
        return mResults.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.text_name);
        }
    }

}