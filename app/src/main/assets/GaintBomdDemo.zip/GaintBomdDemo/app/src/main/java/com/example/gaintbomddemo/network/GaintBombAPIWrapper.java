package com.example.gaintbomddemo.network;

import com.example.gaintbomddemo.model.GaintBombResponse;

import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Query;

public class GaintBombAPIWrapper {

    public static final String BASE_URL = "https://www.giantbomb.com/api/";
    public static final String API_KEY = "https://www.giantbomb.com/api/";
    private GaintBombAPI gaintBombAPI;
    private static GaintBombAPIWrapper bombAPIWrapper;

    private GaintBombAPIWrapper() {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build();
        Retrofit retrofit = new Retrofit.Builder().addConverterFactory(GsonConverterFactory
                .create()).client(okHttpClient)
                .baseUrl(BASE_URL).build();
        gaintBombAPI = retrofit.create(GaintBombAPI.class);
    }

    public static GaintBombAPIWrapper getInstance() {
        if (bombAPIWrapper == null) {
            bombAPIWrapper = new GaintBombAPIWrapper();
        }
        return bombAPIWrapper;
    }

    /**
     *
     * @param query
     * @param callback
     * @return
     */
    public Call<GaintBombResponse> getFoodMenu(String query,
                                               Callback<GaintBombResponse> callback) {
        Call<GaintBombResponse> gaintBombResponse = gaintBombAPI.getGaintBombResponse(API_KEY,
                "json", query, "game");
        gaintBombResponse.enqueue(callback);
        return gaintBombResponse;
    }

}
